#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer


extern int incrementRgbLed(int RGB);
extern int setDelay();

#endif







